echo > minisecret/__init__.py
